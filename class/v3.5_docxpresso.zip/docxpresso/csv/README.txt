This folder stores the required info for a single file conversion.

This folder has to be readable and writable by the web server.