<?php

require_once '../Conversor.inc';

new Docxpresso\Conversor('templates/test_conversion.odt', 'test_conversion.pdf');
