<?php

require_once '../Conversor.inc';

new Docxpresso\Conversor('templates/test_conversion.docx', 'test_conversion.txt');
